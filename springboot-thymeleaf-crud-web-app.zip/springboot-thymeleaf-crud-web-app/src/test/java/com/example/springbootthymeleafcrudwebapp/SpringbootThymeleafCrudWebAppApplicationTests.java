package com.example.springbootthymeleafcrudwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.example.springbootthymeleafcrudwebapp.repository.EmployeeRepository;
import com.example.springbootthymeleafcrudwebapp.service.EmployeeService;

@SpringBootTest
class SpringbootThymeleafCrudWebAppApplicationTests {

	@Autowired
	private EmployeeService employeeService;

	@MockBean
	private EmployeeRepository employeeRepository;
	
	public void getAllEmployessTest(){
		
	}

	@Test
	void contextLoads() {

	}

}
