package optional;

public class isPresent {

}
