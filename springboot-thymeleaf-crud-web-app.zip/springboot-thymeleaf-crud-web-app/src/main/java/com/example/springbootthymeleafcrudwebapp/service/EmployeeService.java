package com.example.springbootthymeleafcrudwebapp.service;

import java.util.List;

import com.example.springbootthymeleafcrudwebapp.model.Employee;

public interface EmployeeService 
{
    List<Employee> getAllEmployess();

    void saveEmployee (Employee employee);

    Employee getEmployeeById(long Id);

    void deleteEmployeeById(long Id);
}
