package com.example.springbootthymeleafcrudwebapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.example.springbootthymeleafcrudwebapp.model.Employee;
import com.example.springbootthymeleafcrudwebapp.service.EmployeeService;

@Controller
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;
    //display list of employess

    @GetMapping("/home")
    public String viewHomePage(Model model){

      // addAttribute method is used to bind data between the model and the view
        model.addAttribute("listEmployees", employeeService.getAllEmployess());
        return "index";
    }

    @GetMapping("/addEmployee")
    public String addEmployee(Model model){
        // create model attribute to bind form data
        Employee employee = new Employee();
        model.addAttribute("employee", employee);
        return "newemployee";
    }

    @PostMapping("/saveEmployee")

    //The @ModelAttribute annotation in the saveEmployee method is used to bind the form data to the Employee object. 
   // When a form is submitted, the data from the form is sent to the server as an HTTP request. 
   // The @ModelAttribute annotation tells Spring to bind the form data to the Employee object.
     public String saveEmployee(@ModelAttribute("employee") Employee employee){
        //save employee to database 
        employeeService.saveEmployee(employee);
        return "redirect:/home";

     }
     
     @GetMapping("/updateForm/{Id}")
     public String updateForm(@PathVariable (value = "Id") long Id, Model model){

        //get employee from service
        Employee employee = employeeService.getEmployeeById(Id);

        //set employee as a model attribute to pre- populate the form 
        model.addAttribute("employee", employee);
        return "updateemployee";

     }

     @GetMapping("/deleteEmployee/{Id}")
     public String deleteEmployee(@PathVariable (value = "Id") long Id){
        //call delete employee
        this.employeeService.deleteEmployeeById(Id);
        return "redirect:/home";

     }
    }
